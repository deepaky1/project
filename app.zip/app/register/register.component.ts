import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {
  public uiInvalidCredential = false;

  public fbFormGroup = this.fb.group({
    firstname: ['', Validators.required],
    lastname: ['', Validators.required],
    accountnumber: ['', Validators.required],
    aadharcardnumber: ['', Validators.required],
    pannumber: ['', Validators.required],
    email: ['', Validators.required],
    contact: ['', Validators.required],
    password: ['', Validators.required],
  });

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private http: HttpClient
  ) {}

  ngOnInit(): void {}

  async registerHere() {
    const data = this.fbFormGroup.value;
    console.log(data);
    const url = 'http://localhost:3000/register';

    await this.http.post(url, data).toPromise();

    this.router.navigate(['login']);
    this.fbFormGroup.reset();
  }
}

//  async registerHere() {
//     const data = this.fbFormGroup.value;
//     console.log(data);
//     const url = 'http://localhost:3000/register';

//     await this.http.post(url, data).toPromise();

//     this.router.navigate(['login']);
//     this.fbFormGroup.reset();
//   }
